document.addEventListener('DOMContentLoaded', (event) => {

    function fillProfile() {
        const status = localStorage.getItem('status');
        const phone = localStorage.getItem('phone');
        const address = localStorage.getItem('address');
        const country = localStorage.getItem('country');

        if (status) document.getElementById('status').value = status;
        if (phone) document.getElementById('phone').value = phone;
        if (address) document.getElementById('address').value = address;
        if (country) document.getElementById('country').value = country;
    }

    function editProfile() {
        document.getElementById('save-profile').style.display = 'block';
        document.getElementById('edit-profile').style.display = 'none';

        document.getElementById('status').readOnly = false;
        document.getElementById('phone').readOnly = false;
        document.getElementById('address').readOnly = false;
        document.getElementById('country').readOnly = false;
    }

    function saveProfile() {
        document.getElementById('save-profile').style.display = 'none';
        document.getElementById('edit-profile').style.display = 'block';

        document.getElementById('status').readOnly = true;
        document.getElementById('phone').readOnly = true;
        document.getElementById('address').readOnly = true;
        document.getElementById('country').readOnly = true;
    }

    fillProfile();

    document.getElementById('edit-profile').addEventListener('click', editProfile);
    document.getElementById('save-profile').addEventListener('click', saveProfile);
        
});